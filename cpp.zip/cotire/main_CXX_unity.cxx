/* cotire.cmake 1.7.10 generated file */
/* /home/duyisking/Documents/cpp/cotire/main_CXX_unity.cxx */
#ifdef __cplusplus
#include "/home/duyisking/Documents/cpp/main.cpp"
#endif
