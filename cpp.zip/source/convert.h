#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <boost/foreach.hpp>
#include "tiny_dnn/tiny_dnn.h"
#include <boost/filesystem.hpp>
using namespace tiny_dnn;
using namespace boost::filesystem;
using namespace std;

// convert image to vec_t
void convert_image(const string &imagefilename,
                      double scale,
                      int w,
                      int h,
                      vector<vec_t> &data)
{
  auto img = cv::imread(imagefilename, cv::IMREAD_COLOR);

  if(img.cols > 200) {
    cv::resize(img, img, cv::Size(200, img.rows * 200 / img.cols));
  }
  if(img.rows > 150) {
    cv::resize(img, img, cv::Size(img.cols * 150 / img.rows, 150));
  }

  cv::Mat background(150, 200, CV_8UC3, cv::Scalar(255, 255, 255));
  img.copyTo(background(cv::Rect(0, 0, img.cols, img.rows)));

  vec_t d;

  for (int i = 0; i < background.rows; i++) {
    for (int j = 0; j < background.cols * 3; j++) {
      d.push_back((double)background.at<uint8_t>(i, j));
    }
  }

  data.push_back(d);
}

// convert all images found in directory to vec_t
void convert_images(const string &directory,
                    double scale,
                    int w,
                    int h,
                    vector<vec_t> &data)
{
  cout << "Open folder " + directory << endl;
  path dpath(directory);
  vector<string> imgs;

  BOOST_FOREACH (const path &p,
                 make_pair(directory_iterator(dpath), directory_iterator()))
  {
    if (is_directory(p))
      continue;
    imgs.push_back(p.string());
  }
  sort(imgs.begin(), imgs.end());
  for (int i = 0; i < imgs.size(); i++)
    convert_image(imgs[i], scale, w, h, data);

  cout << "Successfully opened " + to_string(data.size()) + " files!\n";
}